# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SampleApp::Application.config.secret_token = '00080444add1650be5be1330d7f265c0feed4c7c651f3b3fba50e5064349e8d6f891c924be8776e5a132918ac0acbbb29978c2a80e68d908dca5bfa4612ea6e3'
