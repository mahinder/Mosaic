require 'spec_helper'

describe Tagging do
  pending "add some examples to (or delete) #{__FILE__}"
end
